Quiz de la práctica 2.
